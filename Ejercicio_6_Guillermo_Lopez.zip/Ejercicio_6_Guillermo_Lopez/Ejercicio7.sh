read -p "Dime un numero del mes (1-30) " dia

while [ $dia -le 0 ] || [ $dia -ge 31 ]; do

read -p "Dime un numero del mes (1-31) " dia

done

if  [ $dia == 1 ] || [ $dia == 8 ] ||[ $dia == 15 ] ||[ $dia == 22 ] ||[ $dia == 29 ]; then

echo "El dia $dia es Lunes";

elif [ $dia == 2 ] ||[ $dia == 9 ] ||[ $dia == 16 ] ||[ $dia == 23 ] ||[ $dia == 30 ]; then

echo "El dia $dia es Martes";

elif [ $dia == 3 ] ||[ $dia == 10 ] ||[ $dia == 17 ] ||[ $dia == 24 ]; then

echo "El dia $dia es Miercoles";

elif [ $dia == 4 ] ||[ $dia == 11 ] ||[ $dia == 18 ] ||[ $dia == 25 ]; then

echo "El dia $dia es Jueves";

elif [ $dia == 5 ] ||[ $dia == 12 ] ||[ $dia == 19 ] ||[ $dia == 26 ]; then

echo "El dia $dia es Viernes";

elif [ $dia == 6 ] ||[ $dia == 13 ] ||[ $dia == 20 ] ||[ $dia == 27 ]; then

echo "El dia $dia es Sabado"

elif [ $dia == 7 ] ||[ $dia == 14 ] ||[ $dia == 21 ] ||[ $dia == 28 ];then


echo "El dia $dia es Domindo"


fi
