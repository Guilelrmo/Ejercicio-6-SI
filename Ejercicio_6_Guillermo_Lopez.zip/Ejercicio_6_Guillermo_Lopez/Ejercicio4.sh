read -p "Dime un numero mayor que 0 " numero

while [ $numero -le 0 ]; do

read -p "Dime un numero mayor que 0 " numero

done

for i in `seq 0 $numero`; do

echo "El valor es $i"

done
