read -p "Dime numeros hasta poner 0 " numero

contador=0
valor=0


while [ $numero -ne 0 ]; do

valor=`expr $numero + $valor`

read -p "Dime numeros hasta poner 0 " numero

contador=`expr $contador + 1`

total=$(echo "scale=1; $valor / $contador" |bc)

done
echo "Total suma $valor"
echo "La media es $total"




