echo "---Listado de posibles notas---"
echo  "Suspendido < 5"
echo  "Aprobado = 5"
echo  "Bien entre 6 y 8"
echo  "Notable = 9"
echo  "Sobresaliente = 10" 
echo "---------------------------------"
read -p "Dime tu nota y te digo la calificacion " nota

while [ $nota -le 0 ] || [ $nota -ge 11 ]; do

read -p "Dime tu nota y te digo la calificacion " nota

done

if  [ $nota -lt 5 ]; then

echo "Estas Suspedido, Estudia mas!!";

elif [ $nota -eq 5 ]; then

echo "Estas Aprobado pero por los pelos";

elif [ $nota -eq 9 ]; then

echo "Esta Notable enhorabuena!!";

elif [ $nota -eq  10 ]; then 

echo "Enhorabuena!! esta Perfecto Sobresaliente";


elif [ $nota -ge 6 ] || [ $nota -le 8 ]; then

echo "Esta Bien pero no te relajes";

fi
