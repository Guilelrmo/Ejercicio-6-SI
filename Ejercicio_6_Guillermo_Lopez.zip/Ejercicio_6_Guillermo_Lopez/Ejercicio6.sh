read -p "Dime cantidad de litros " litros

while [ $litros -eq 0 ]; do

read -p "Dime cantidad de litros " litros

done

precio1=0.40
precio2=0.20
precio3=0.10

if [ $litros -le 50 ]; then

total1=$(echo "scale=2; $precio1 * $litros" |bc)

echo "El total por los $litros Litros es $total1""€";

elif  [ $litros -le 200 ]; then

totallitros=`expr $litros - 50`

totalprecio1=$(echo "scale=1; 50 * $precio1" |bc)

totalprecio2=$(echo "scale=1; $totallitros * $precio2" |bc)

total2=$(echo "scale=1; $totalprecio1 + $totalprecio2" |bc)

echo "El total por los $litros Litros es $total2""€";

elif  [ $litros -gt 200 ]; then 

totallitros1=`expr $litros - 250`

totalprecio1=$(echo "scale=1; 50 * $precio1" |bc)

totalprecio2=$(echo "scale=1; 200 * $precio2" |bc)

totalprecio3=$(echo "scale=1; $totallitros1 * $precio3" |bc)

total3=$(echo "scale=1; $totalprecio1 + $totalprecio2 + $totalprecio3" |bc)

echo "El total por los $litros Litros es $total3""€";

fi
