read -p "Dime un numero: " numero1
read -p "Dime otro numero: " numero2

if [ $numero1 -lt $numero2 ]; then
	 echo "El numero $numero2 es mas mayor que $numero1";
elif [ $numero2  -lt $numero1 ]; then
	 echo "El numero $numero1 es mas mayor que $numero2";
else
	 echo "Los numero $numero1 y  $numero2 son iguales";
fi

