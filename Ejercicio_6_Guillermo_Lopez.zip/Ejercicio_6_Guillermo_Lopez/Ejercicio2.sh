read -p "Dime un numero mayor que 0 " numero

while [ $numero -le 0 ]; do

read -p "Dime un numero mayor que 0 " numero

done

resto=`expr $numero % 2`

if [ $resto -eq 0 ]; then

echo "El numero $numero es par ";

else 

echo "El numero $numero es impar";
fi
